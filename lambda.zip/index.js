var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback){
  var alexa = Alexa.handler(event, context);
  // alexa.APP_ID = 'amzn1.ask.skill.458a4a08-6764-4e37-9363-6d054ac4e645';
  alexa.registerHandlers(handlers);
  alexa.execute();
};

var handlers = {

  'LaunchRequest': function () {
    this.emit(':ask','Hello world!  Say the name of an artist.', 'Try saying the name of an artist');
  },

  'ArtistName': function() {
    var artistName = this.event.request.intent.slots.artist.value;
    // require the request package
    var request = require('request');

    // set up variables used in the API request
    var artist = artistName;
    var api_key = '81e78ef30ab28fd04ac12e9041703ef3'; 
    artist = encodeURIComponent(artist);
    
    // generate the url
    var endpoint = 'http://ws.audioscrobbler.com/2.0/?method=artist.gettopalbums&artist='+
                      artist +'&api_key='+api_key+'&format=json';
    console.log('Got the following artistName: ' + artistName);
    console.log('URL: ' + endpoint);
    // we're issuing a GET request here, so we use the get method in the request object
    request.get(endpoint, (error, response, body) => {
        if(response.statusCode !== 200) {
            this.emit(':ask','There was an error processing your request.');
        } else {
            // parse the data into a JSON object
            data = JSON.parse(body);
            // notice the two different ways we can access JSON objects below:
            //artist = data["topalbums"]["@attr"]["artist"];
            topalbums = data.topalbums.album;

            // let's sort by playcount in descending order so it makes a little more sense
            topalbums.sort(function(a, b) {
                return parseFloat(b.playcount) - parseFloat(a.playcount);
            });
  
            this.emit(':ask','The number one album for ' + artist + ' is ' + topalbums[0].name + '.');
        }
    });
  },

  'AMAZON.StopIntent': function () {
    // State Automatically Saved with :tell
    this.emit(':tell', `Goodbye.`);
  },
  'AMAZON.CancelIntent': function () {
    // State Automatically Saved with :tell
    this.emit(':tell', `Goodbye.`);
  },
  'SessionEndedRequest': function () {
    // Force State Save When User Times Out
    this.emit(':saveState', true);
  },

  'AMAZON.HelpIntent' : function () {
    this.emit(':ask', `You can tell me the name of a musical artist and I will say it back to you.  Who would you like me to find?`,  `Who would you like me to find?`);
  },
  'Unhandled' : function () {
    this.emit(':ask', `You can tell me the name of a musical artist and I will say it back to you.  Who would you like me to find?`,  `Who would you like me to find?`);
  }

};